import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-blank',
  templateUrl: './profile-blank.component.html',
  styleUrls: ['./profile-blank.component.css']
})
export class ProfileBlankComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
