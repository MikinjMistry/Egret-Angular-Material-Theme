import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab',
  templateUrl: './app-tab.component.html',
  styleUrls: ['./app-tab.component.css']
})
export class AppTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
